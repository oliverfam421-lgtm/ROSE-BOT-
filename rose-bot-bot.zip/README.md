# Rose bot

A small, dependable bot for your community.

## Run locally

1. Copy `.env.example` to `.env` and add your Discord token.
2. Run `npm install`.
3. Run `npm run register` once to publish the slash commands.
4. Run `npm start`.

## Commands

- `/ping`
- `/poll`
- `/announce`
- `/profile`

## Deploy on Render

1. Push this folder to a new GitHub repository.
2. In Render, choose **New > Background Worker** and connect the repository.
3. Render can use the included `render.yaml`; add `DISCORD_TOKEN` and `DISCORD_CLIENT_ID` when prompted.
4. Use `npm install` as the build command and `npm start` as the start command if Render asks for them.

Keep your real `.env` file and Discord token out of GitHub.
