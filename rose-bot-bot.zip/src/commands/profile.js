import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('profile')
    .setDescription('Show a member profile.'),
  async execute(interaction) {
    await interaction.reply({ content: 'The /profile command is connected.' });
  },
};
