import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('poll')
    .setDescription('Start a quick community poll.'),
  async execute(interaction) {
    await interaction.reply({ content: 'The /poll command is connected.' });
  },
};
