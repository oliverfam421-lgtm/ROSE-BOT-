import ping from '../src/commands/ping.js';
import poll from '../src/commands/poll.js';
import announce from '../src/commands/announce.js';
import profile from '../src/commands/profile.js';
import { REST, Routes } from 'discord.js';
import 'dotenv/config';

const commands = [ping.data.toJSON(), poll.data.toJSON(), announce.data.toJSON(), profile.data.toJSON()];
const rest = new REST().setToken(process.env.DISCORD_TOKEN);
await rest.put(Routes.applicationCommands(process.env.DISCORD_CLIENT_ID), { body: commands });
console.log('Slash commands registered.');
