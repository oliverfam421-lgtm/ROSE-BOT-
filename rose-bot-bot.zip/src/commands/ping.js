import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Check the bot response time.'),
  async execute(interaction) {
    await interaction.reply({ content: `Pong — ${interaction.client.ws.ping}ms` });
  },
};
