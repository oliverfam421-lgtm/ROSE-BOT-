import { Client, Collection, GatewayIntentBits } from 'discord.js';
import 'dotenv/config';
import ping from './commands/ping.js';
import poll from './commands/poll.js';
import announce from './commands/announce.js';
import profile from './commands/profile.js';

const client = new Client({ intents: [GatewayIntentBits.Guilds] });
const commands = new Collection();
[ping, poll, announce, profile].forEach((command) => commands.set(command.data.name, command));

client.once('ready', () => console.log(`Ready as ${client.user.tag}`));
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isChatInputCommand()) return;
  const command = commands.get(interaction.commandName);
  if (command) await command.execute(interaction);
});

client.login(process.env.DISCORD_TOKEN);
