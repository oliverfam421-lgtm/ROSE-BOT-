import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('announce')
    .setDescription('Post an announcement.'),
  async execute(interaction) {
    await interaction.reply({ content: 'The /announce command is connected.' });
  },
};
